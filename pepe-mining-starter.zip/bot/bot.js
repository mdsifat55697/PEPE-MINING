import 'dotenv/config';
import { Bot, InlineKeyboard } from 'grammy';

const token = process.env.BOT_TOKEN;
const webapp = process.env.WEBAPP_URL;
if (!token) throw new Error('Set BOT_TOKEN in .env');
if (!webapp || !webapp.startsWith('https://')) throw new Error('Set WEBAPP_URL to your HTTPS Mini App URL.');

const bot = new Bot(token);
const username = (process.env.BOT_USERNAME || '').replace(/^@/, '');

bot.command('start', async ctx => {
  const payload = String(ctx.match || '').trim();
  const referral = /^\d+$/.test(payload) ? payload : '';
  const url = referral ? `${webapp}?startapp=${encodeURIComponent(referral)}` : webapp;
  const keyboard = new InlineKeyboard().webApp('🚀 Open PEPE MINING', url);
  await ctx.reply(
    '🐸 Welcome to PEPE MINING!\n\n' +
    'Complete tasks, invite friends, and track your PEPE / PP balances.\n' +
    (referral ? 'Referral link detected. Open the app to register.\n' : '') +
    '\nOnly verified tasks receive rewards. Token balances in this app are internal points unless an actual token contract and payout system are configured.',
    { reply_markup: keyboard }
  );
});

bot.command('help', ctx => ctx.reply('Use /start to open PEPE MINING. For account help, open the Mini App and visit Profile.'));
bot.catch(err => console.error('Bot error:', err));
bot.start();
console.log('PEPE MINING bot is running.');
