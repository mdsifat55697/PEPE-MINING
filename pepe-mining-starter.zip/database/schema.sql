CREATE TABLE IF NOT EXISTS users (
  id BIGINT PRIMARY KEY,                       -- Telegram numeric user ID
  username TEXT,
  first_name TEXT NOT NULL DEFAULT '',
  photo_url TEXT,
  bsc_address TEXT,
  pepe_balance BIGINT NOT NULL DEFAULT 0 CHECK (pepe_balance >= 0),
  pp_balance BIGINT NOT NULL DEFAULT 0 CHECK (pp_balance >= 0),
  referred_by BIGINT REFERENCES users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CHECK (referred_by IS NULL OR referred_by <> id)
);

CREATE TABLE IF NOT EXISTS tasks (
  id SERIAL PRIMARY KEY,
  kind TEXT NOT NULL CHECK (kind IN ('ad', 'social')),
  title TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  url TEXT,
  reward BIGINT NOT NULL CHECK (reward > 0),
  daily_limit INTEGER,
  active BOOLEAN NOT NULL DEFAULT TRUE,
  verification_mode TEXT NOT NULL DEFAULT 'manual'
    CHECK (verification_mode IN ('manual', 'provider', 'admin')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS task_claims (
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  task_id INTEGER NOT NULL REFERENCES tasks(id),
  claim_date DATE NOT NULL DEFAULT CURRENT_DATE,
  status TEXT NOT NULL DEFAULT 'pending'
    CHECK (status IN ('pending', 'approved', 'rejected')),
  reward BIGINT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  reviewed_at TIMESTAMPTZ,
  UNIQUE(user_id, task_id, claim_date)
);

CREATE TABLE IF NOT EXISTS referral_rewards (
  id BIGSERIAL PRIMARY KEY,
  beneficiary_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  source_user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  level INTEGER NOT NULL CHECK (level BETWEEN 1 AND 3),
  base_amount BIGINT NOT NULL,
  reward_amount BIGINT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(beneficiary_id, source_user_id, level)
);

CREATE TABLE IF NOT EXISTS transactions (
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  asset TEXT NOT NULL CHECK (asset IN ('PEPE', 'PP')),
  amount BIGINT NOT NULL,
  reason TEXT NOT NULL,
  reference_id TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS withdrawals (
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  asset TEXT NOT NULL DEFAULT 'PEPE' CHECK (asset IN ('PEPE')),
  amount BIGINT NOT NULL CHECK (amount > 0),
  destination TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending'
    CHECK (status IN ('pending', 'approved', 'rejected', 'paid')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  reviewed_at TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_task_claims_user_date ON task_claims(user_id, claim_date);
CREATE INDEX IF NOT EXISTS idx_transactions_user_created ON transactions(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_withdrawals_user_created ON withdrawals(user_id, created_at DESC);

INSERT INTO tasks(kind, title, description, reward, daily_limit, verification_mode)
SELECT 'ad', 'Rewarded Ad', 'Watch one approved rewarded ad. Reward is credited after the ad provider confirms completion.', 1000, 10, 'provider'
WHERE NOT EXISTS (SELECT 1 FROM tasks WHERE kind='ad' AND title='Rewarded Ad');

INSERT INTO tasks(kind, title, description, reward, verification_mode)
SELECT 'social', 'Follow our official channel', 'Follow the official social account and submit for review.', 1000, 'manual'
WHERE NOT EXISTS (SELECT 1 FROM tasks WHERE kind='social' AND title='Follow our official channel');
