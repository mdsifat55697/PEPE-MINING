# PEPE MINING starter

A Telegram Mini App + Bot starter with Express, PostgreSQL, task claims, profile, referral tracking, and manual withdrawal requests.

## Important limitations
- PEPE and PP are **database points** in this starter, not on-chain assets. Do not advertise a token listing or guaranteed cash value.
- Ad rewards require a real rewarded-ad provider and server-to-server verification. The starter deliberately queues claims for approval rather than trusting a browser button.
- Social tasks are manually reviewed. The sample referral page shows the requested 5% / 2% / 1% rates, but no referral commission is credited yet: define the commission base and qualifying event, then implement it server-side before enabling payouts.
- Withdrawals are manual requests only; no private keys or automated blockchain transfers are included.
- For production, add rate limiting, audit logs, monitoring, CSRF/origin controls where applicable, and admin review tooling. Keep secrets out of the frontend.

## Local setup
1. Install Node.js 22+ and Docker Compose.
2. Copy `.env.example` to `.env`.
3. Set `BOT_TOKEN`, `BOT_USERNAME`, `WEBAPP_URL` (HTTPS public URL), and a strong `POSTGRES_PASSWORD`.
4. Update `DATABASE_URL` in `.env` to match your chosen credentials. For Docker Compose the API environment overrides the database host.
5. Start the API and database:
   `docker compose up --build -d`
6. Start the Telegram bot:
   `docker compose up -d bot`
7. Point your HTTPS web server / hosting static site at `index.html`, and configure the BotFather Mini App URL to that HTTPS URL.
8. The API must be publicly reachable over HTTPS at the same origin as `index.html`, or configure a reverse proxy and update the fetch paths in `index.html`.

## Environment
Compose expects `POSTGRES_PASSWORD`. Add:
```
POSTGRES_USER=pepe_user
POSTGRES_PASSWORD=use-a-long-random-password
POSTGRES_DB=pepe_mining
BOT_TOKEN=your-real-bot-token
BOT_USERNAME=your_bot_username_without_at
WEBAPP_URL=https://your-domain.example
ADMIN_TELEGRAM_IDS=your_numeric_telegram_id
COOKIE_SECURE=true
```
Set `DATABASE_URL` for non-Compose deployments, e.g. `postgres://pepe_user:password@localhost:5432/pepe_mining`.

## Admin task approval
The API exposes `POST /api/admin/claims/:claimId/review` with JSON `{"decision":"approve"}` or `{"decision":"reject"}`. It uses Telegram Mini App initData auth and `ADMIN_TELEGRAM_IDS`. Use a secure admin-only client or implement a separate protected admin panel; never put bot tokens in the browser.

## Referral behavior
A new user can be registered under a referrer only if the referrer already exists in the database. The frontend generates `https://t.me/<BOT_USERNAME>?start=<id>`. Telegram Mini Apps may pass a `start_param`; the app forwards it to `/api/session`. For a production bot, use BotFather's Mini App configuration and test the deep-link behavior on Android/iOS/Desktop.

## Database migrations
`schema.sql` is run automatically only on first initialization of the PostgreSQL data volume. For later schema changes, use explicit migrations.
