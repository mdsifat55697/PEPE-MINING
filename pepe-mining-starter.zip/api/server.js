import 'dotenv/config';
import express from 'express';
import crypto from 'node:crypto';
import pg from 'pg';

const { Pool } = pg;
const app = express();
app.use(express.json({ limit: '32kb' }));

const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const BOT_TOKEN = process.env.BOT_TOKEN;
const PORT = Number(process.env.PORT || 4000);
const ADMIN_IDS = new Set((process.env.ADMIN_TELEGRAM_IDS || '').split(',').map(s => s.trim()).filter(Boolean));

if (!BOT_TOKEN) console.warn('WARNING: BOT_TOKEN is not set. Telegram initData validation will fail.');

function validateTelegramInitData(initData) {
  if (!BOT_TOKEN || typeof initData !== 'string' || !initData) return null;
  const params = new URLSearchParams(initData);
  const hash = params.get('hash');
  const authDate = Number(params.get('auth_date'));
  if (!hash || !Number.isFinite(authDate)) return null;
  // Reject old initData (24 hours). In production, consider a shorter window.
  if (Math.abs(Math.floor(Date.now() / 1000) - authDate) > 86400) return null;
  params.delete('hash');
  const dataCheckString = [...params.entries()]
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([k, v]) => `${k}=${v}`)
    .join('\n');
  const secretKey = crypto.createHmac('sha256', 'WebAppData').update(BOT_TOKEN).digest();
  const calculated = crypto.createHmac('sha256', secretKey).update(dataCheckString).digest('hex');
  const a = Buffer.from(calculated, 'hex');
  const b = Buffer.from(hash, 'hex');
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
  try {
    const user = JSON.parse(params.get('user') || 'null');
    if (!user || !Number.isSafeInteger(Number(user.id))) return null;
    return { ...user, id: String(user.id) };
  } catch { return null; }
}

async function auth(req, res, next) {
  const initData = req.get('X-Telegram-Init-Data') || '';
  const user = validateTelegramInitData(initData);
  if (!user) return res.status(401).json({ error: 'Invalid or expired Telegram session. Open this app from Telegram.' });
  req.tgUser = user;
  next();
}

async function ensureUser(tgUser, startParam = '') {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    let referrerId = null;
    if (/^\d+$/.test(startParam) && startParam !== String(tgUser.id)) {
      const exists = await client.query('SELECT id FROM users WHERE id=$1', [startParam]);
      if (exists.rowCount) referrerId = startParam;
    }
    const inserted = await client.query(`
      INSERT INTO users(id, username, first_name, photo_url, referred_by)
      VALUES($1,$2,$3,$4,$5)
      ON CONFLICT(id) DO UPDATE SET username=EXCLUDED.username,
        first_name=EXCLUDED.first_name,
        photo_url=COALESCE(EXCLUDED.photo_url, users.photo_url),
        updated_at=NOW()
      RETURNING (xmax = 0) AS is_new
    `, [tgUser.id, tgUser.username || null, tgUser.first_name || '', tgUser.photo_url || null, referrerId]);
    // One-time direct referral bonus, only for a genuinely new account.
    if (inserted.rows[0]?.is_new && referrerId) {
      await client.query('UPDATE users SET pepe_balance=pepe_balance+3000 WHERE id=$1', [referrerId]);
      await client.query(`INSERT INTO transactions(user_id,asset,amount,reason,reference_id)
        VALUES($1,'PEPE',3000,'direct_referral_bonus',$2)`, [referrerId, String(tgUser.id)]);
    }
    await client.query('COMMIT');
  } catch (e) {
    await client.query('ROLLBACK');
    throw e;
  } finally { client.release(); }
}

app.get('/health', (_req, res) => res.json({ ok: true, service: 'pepe-mining-api' }));

app.use('/api', auth);

app.post('/api/session', async (req, res, next) => {
  try {
    await ensureUser(req.tgUser, String(req.body?.startParam || ''));
    const result = await pool.query('SELECT id, username, first_name, photo_url, bsc_address, pepe_balance, pp_balance, created_at FROM users WHERE id=$1', [req.tgUser.id]);
    res.json({ user: result.rows[0] });
  } catch (e) { next(e); }
});

app.get('/api/me', async (req, res, next) => {
  try {
    const u = await pool.query('SELECT id, username, first_name, photo_url, bsc_address, pepe_balance, pp_balance, created_at FROM users WHERE id=$1', [req.tgUser.id]);
    if (!u.rowCount) return res.status(404).json({ error: 'User not initialized. POST /api/session first.' });
    const referrals = await pool.query('SELECT COUNT(*)::int AS count FROM users WHERE referred_by=$1', [req.tgUser.id]);
    res.json({ user: u.rows[0], referralCount: referrals.rows[0].count });
  } catch (e) { next(e); }
});

app.patch('/api/profile', async (req, res, next) => {
  try {
    const firstName = String(req.body?.firstName ?? req.tgUser.first_name ?? '').trim().slice(0, 64);
    const bsc = String(req.body?.bscAddress ?? '').trim();
    if (bsc && !/^0x[a-fA-F0-9]{40}$/.test(bsc)) return res.status(400).json({ error: 'Enter a valid BSC/EVM wallet address (0x + 40 hex characters).' });
    const r = await pool.query(
      'UPDATE users SET first_name=$2, bsc_address=$3, updated_at=NOW() WHERE id=$1 RETURNING id, username, first_name, photo_url, bsc_address, pepe_balance, pp_balance',
      [req.tgUser.id, firstName, bsc || null]);
    res.json({ user: r.rows[0] });
  } catch (e) { next(e); }
});

app.get('/api/tasks', async (req, res, next) => {
  try {
    const r = await pool.query(`
      SELECT t.id, t.kind, t.title, t.description, t.url, t.reward, t.daily_limit,
        COALESCE(c.status, 'available') AS user_status
      FROM tasks t
      LEFT JOIN task_claims c ON c.task_id=t.id AND c.user_id=$1 AND c.claim_date=CURRENT_DATE
      WHERE t.active=TRUE ORDER BY t.id
    `, [req.tgUser.id]);
    const ads = await pool.query(`SELECT COUNT(*)::int AS used FROM task_claims c JOIN tasks t ON t.id=c.task_id
      WHERE c.user_id=$1 AND c.claim_date=CURRENT_DATE AND t.kind='ad' AND c.status IN ('pending','approved')`, [req.tgUser.id]);
    res.json({ tasks: r.rows, adsUsedToday: ads.rows[0].used, adsDailyLimit: 10 });
  } catch (e) { next(e); }
});

// Claims are pending until a trusted provider/admin confirms completion.
// Never credit rewards based only on a client-side "I watched it" button.
app.post('/api/tasks/:id/claim', async (req, res, next) => {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const taskR = await client.query('SELECT * FROM tasks WHERE id=$1 AND active=TRUE FOR UPDATE', [req.params.id]);
    if (!taskR.rowCount) { await client.query('ROLLBACK'); return res.status(404).json({ error: 'Task not found.' }); }
    const task = taskR.rows[0];
    if (task.kind === 'ad') {
      const used = await client.query(`SELECT COUNT(*)::int AS n FROM task_claims c JOIN tasks t ON t.id=c.task_id
        WHERE c.user_id=$1 AND c.claim_date=CURRENT_DATE AND t.kind='ad' AND c.status IN ('pending','approved')`, [req.tgUser.id]);
      if (used.rows[0].n >= 10) { await client.query('ROLLBACK'); return res.status(429).json({ error: 'Daily ad limit reached.' }); }
    }
    const prior = await client.query('SELECT id FROM task_claims WHERE user_id=$1 AND task_id=$2 AND claim_date=CURRENT_DATE', [req.tgUser.id, task.id]);
    if (prior.rowCount) { await client.query('ROLLBACK'); return res.status(409).json({ error: 'Already submitted this task today.' }); }
    const c = await client.query(`INSERT INTO task_claims(user_id, task_id, reward, status)
      VALUES($1,$2,$3,'pending') RETURNING id,status,reward`, [req.tgUser.id, task.id, task.reward]);
    await client.query('COMMIT');
    res.status(202).json({ claim: c.rows[0], message: 'Submitted for verification. Rewards are credited after approval.' });
  } catch (e) { await client.query('ROLLBACK'); next(e); }
  finally { client.release(); }
});

app.get('/api/referrals', async (req, res, next) => {
  try {
    const direct = await pool.query('SELECT COUNT(*)::int AS count FROM users WHERE referred_by=$1', [req.tgUser.id]);
    const rewards = await pool.query(`SELECT level, COALESCE(SUM(reward_amount),0)::bigint AS total
      FROM referral_rewards WHERE beneficiary_id=$1 GROUP BY level ORDER BY level`, [req.tgUser.id]);
    res.json({ directReferrals: direct.rows[0].count, rewardsByLevel: rewards.rows,
      referralCode: String(req.tgUser.id), botUsername: process.env.BOT_USERNAME || '' });
  } catch (e) { next(e); }
});

app.get('/api/wallet', async (req, res, next) => {
  try {
    const [u, tx, withdrawals] = await Promise.all([
      pool.query('SELECT pepe_balance, pp_balance, bsc_address FROM users WHERE id=$1', [req.tgUser.id]),
      pool.query('SELECT asset, amount, reason, created_at FROM transactions WHERE user_id=$1 ORDER BY created_at DESC LIMIT 50', [req.tgUser.id]),
      pool.query('SELECT id, amount, destination, status, created_at FROM withdrawals WHERE user_id=$1 ORDER BY created_at DESC LIMIT 20', [req.tgUser.id])
    ]);
    res.json({ wallet: u.rows[0], transactions: tx.rows, withdrawals: withdrawals.rows });
  } catch (e) { next(e); }
});

app.post('/api/withdrawals', async (req, res, next) => {
  const amount = Number(req.body?.amount);
  const destination = String(req.body?.destination || '').trim();
  if (!Number.isSafeInteger(amount) || amount <= 0) return res.status(400).json({ error: 'Amount must be a positive whole number.' });
  if (!/^0x[a-fA-F0-9]{40}$/.test(destination)) return res.status(400).json({ error: 'Invalid BSC wallet address.' });
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const u = await client.query('SELECT pepe_balance FROM users WHERE id=$1 FOR UPDATE', [req.tgUser.id]);
    if (!u.rowCount || BigInt(u.rows[0].pepe_balance) < BigInt(amount)) {
      await client.query('ROLLBACK'); return res.status(400).json({ error: 'Insufficient PEPE balance.' });
    }
    await client.query('UPDATE users SET pepe_balance=pepe_balance-$2 WHERE id=$1', [req.tgUser.id, amount]);
    await client.query(`INSERT INTO transactions(user_id,asset,amount,reason) VALUES($1,'PEPE',$2,'withdrawal_hold')`, [req.tgUser.id, -amount]);
    const w = await client.query(`INSERT INTO withdrawals(user_id,amount,destination) VALUES($1,$2,$3) RETURNING id,amount,destination,status,created_at`, [req.tgUser.id, amount, destination]);
    await client.query('COMMIT');
    res.status(201).json({ withdrawal: w.rows[0], message: 'Withdrawal request submitted for manual review.' });
  } catch (e) { await client.query('ROLLBACK'); next(e); }
  finally { client.release(); }
});

// Admin-only manual review endpoints. Protect ADMIN_TELEGRAM_IDS and the server itself.
app.post('/api/admin/claims/:claimId/review', async (req, res, next) => {
  if (!ADMIN_IDS.has(String(req.tgUser.id))) return res.status(403).json({ error: 'Admin only.' });
  const decision = req.body?.decision;
  if (!['approve', 'reject'].includes(decision)) return res.status(400).json({ error: 'decision must be approve or reject.' });
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const cr = await client.query(`SELECT c.*,t.kind FROM task_claims c JOIN tasks t ON t.id=c.task_id WHERE c.id=$1 FOR UPDATE`, [req.params.claimId]);
    if (!cr.rowCount || cr.rows[0].status !== 'pending') { await client.query('ROLLBACK'); return res.status(404).json({ error: 'Pending claim not found.' }); }
    const c = cr.rows[0];
    const status = decision === 'approve' ? 'approved' : 'rejected';
    await client.query('UPDATE task_claims SET status=$2,reviewed_at=NOW() WHERE id=$1', [c.id, status]);
    if (decision === 'approve') {
      const asset = c.kind === 'ad' ? 'PP' : 'PEPE';
      const col = asset === 'PP' ? 'pp_balance' : 'pepe_balance';
      await client.query(`UPDATE users SET ${col}=${col}+$2 WHERE id=$1`, [c.user_id, c.reward]);
      await client.query('INSERT INTO transactions(user_id,asset,amount,reason,reference_id) VALUES($1,$2,$3,$4,$5)',
        [c.user_id, asset, c.reward, 'task_reward', String(c.id)]);
      // Multi-level referral commissions are based on approved task rewards in this starter.
      // Level 1/2/3 rates: 5%, 2%, 1%. Only PEPE task rewards generate PEPE commissions.
      if (asset === 'PEPE') {
        const chain = await client.query(`
          WITH RECURSIVE uplines(id, referred_by, level) AS (
            SELECT u.id, u.referred_by, 0 FROM users u WHERE u.id=$1
            UNION ALL
            SELECT p.id, p.referred_by, uplines.level+1
            FROM users p JOIN uplines ON p.id=uplines.referred_by
            WHERE uplines.level < 3
          )
          SELECT id, level FROM uplines WHERE level BETWEEN 1 AND 3
        `, [c.user_id]);
        const rates = {1: 5, 2: 2, 3: 1};
        for (const parent of chain.rows) {
          const rewardAmount = Math.floor(Number(c.reward) * rates[parent.level] / 100);
          if (rewardAmount <= 0) continue;
          await client.query('UPDATE users SET pepe_balance=pepe_balance+$2 WHERE id=$1', [parent.id, rewardAmount]);
          await client.query(`INSERT INTO referral_rewards(beneficiary_id,source_user_id,level,base_amount,reward_amount)
            VALUES($1,$2,$3,$4,$5) ON CONFLICT(beneficiary_id,source_user_id,level) DO NOTHING`,
            [parent.id, c.user_id, parent.level, c.reward, rewardAmount]);
          await client.query(`INSERT INTO transactions(user_id,asset,amount,reason,reference_id)
            VALUES($1,'PEPE',$2,$3,$4)`,
            [parent.id, rewardAmount, `level_${parent.level}_referral_reward`, String(c.id)]);
        }
      }
    }
    await client.query('COMMIT');
    res.json({ ok: true, status });
  } catch (e) { await client.query('ROLLBACK'); next(e); }
  finally { client.release(); }
});

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: 'Internal server error.' });
});

app.listen(PORT, () => console.log(`PEPE MINING API listening on ${PORT}`));
